Estructura de assets con tamaños recomendados:
background.png                 1080x1920
dojo_interior.png              1080x1920
neon_luces.png                 1080x1920
humo_glow.png                  1080x1920
platform_spritesheet.png       1536x512
platform.png                   512x128
slash_effect.png               512x512
smoke_effect.png               512x512
sparks.png                     256x256
sword.png                      256x256
shield.png                     256x256
button_buy.png                 256x64
button_sell.png                256x64
button_battle.png              256x64
avatar.png                     512x512
